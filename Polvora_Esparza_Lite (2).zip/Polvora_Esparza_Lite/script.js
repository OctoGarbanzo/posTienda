

// DOM Elements
const productGrid = document.getElementById('product-grid');
const categoryFilters = document.getElementById('category-filters');
const cartModal = document.getElementById('cart-modal');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');
const cartCountEl = document.getElementById('cart-count');
const storeNameEl = document.getElementById('store-name');

// DOM Elements (Product Modal)
const productModal = document.getElementById('product-modal');
const carouselContainer = document.getElementById('carousel-container');
const modalDots = document.getElementById('modal-dots');
const modalTitle = document.getElementById('modal-title');
const modalPrice = document.getElementById('modal-price');
const modalDesc = document.getElementById('modal-desc');
const modalSizesContainer = document.getElementById('modal-sizes-container');
const modalAddBtn = document.getElementById('modal-add-btn');
const closeModalBtn = document.getElementById('close-modal');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

// Quantity Elements
const qtyInput = document.getElementById('qty-input');
const qtyMinus = document.getElementById('qty-minus');
const qtyPlus = document.getElementById('qty-plus');

// State
let products = [];
let cart = [];
try {
    cart = JSON.parse(localStorage.getItem('cart')) || [];
} catch (e) {
    console.error('Error parsing cart from localStorage:', e);
    cart = [];
}

let whatsappNumber = '';
let storeName = 'Mi Tienda';
let currentProduct = null;
let currentMediaIndex = 0;
let isZoomed = false;

// Initialize
async function init() {

    try {
        const response = await fetch('products.json?v=' + Date.now() + '13');

        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

        const data = await response.json();


        products = data.products;

        // Sort: Active items first, Sold Out (price 0) last
        products.sort((a, b) => {
            const isSoldOutA = a.price == 0 || a.price === '0';
            const isSoldOutB = b.price == 0 || b.price === '0';
            if (isSoldOutA && !isSoldOutB) return 1;
            if (!isSoldOutA && isSoldOutB) return -1;
            return 0;
        });


        if (!products) {
            console.error('Products array is missing in JSON');
            throw new Error('Formato de productos incorrecto en JSON');
        }

        whatsappNumber = data.settings.whatsapp;
        storeName = data.settings.storeName;

        // Dynamic Theming
        if (data.settings.primaryColor) {
            document.documentElement.style.setProperty('--primary', data.settings.primaryColor);
        }
        if (data.settings.bgColor) {
            document.documentElement.style.setProperty('--bg-color', data.settings.bgColor);
        }

        document.title = storeName;
        storeNameEl.textContent = storeName;

        renderCategories();
        renderProducts('all');
        updateCartUI();


    } catch (error) {
        console.error('Error loading products:', error);
        productGrid.innerHTML = `<p class="error" style="color:white; padding:2rem; text-align:center">Error cargando productos: ${error.message}. Por favor verifica products.json</p>`;
    }
}

// Render Categories
function renderCategories() {
    const categories = ['all', ...new Set(products.map(p => p.category))];

    categoryFilters.innerHTML = categories.map(cat => `
        <button class="filter-btn ${cat === 'all' ? 'active' : ''}"
                onclick="filterProducts('${cat}')">
            ${cat.charAt(0).toUpperCase() + cat.slice(1)}
        </button>
    `).join('');

    // Start Auto Scroll
    setupAutoScroll();
}

function setupAutoScroll() {
    const filters = categoryFilters; // Use the global variable
    if (!filters) return;

    let scrollSpeed = 0.5;
    let isPaused = false;
    let direction = 1; // 1 = right, -1 = left
    let animationId = null;

    // Pause on interaction
    const pause = () => isPaused = true;
    const resume = () => isPaused = false;
    const resumeDelayed = () => setTimeout(() => isPaused = false, 2000);

    filters.removeEventListener('touchstart', pause); // Clean previous if any
    filters.addEventListener('touchstart', pause);
    filters.addEventListener('touchend', resumeDelayed);
    filters.addEventListener('mouseenter', pause);
    filters.addEventListener('mouseleave', resume);

    function scroll() {
        if (!isPaused) {
            // Buffer of 2px to avoid stuck logic
            if (direction === 1 && filters.scrollLeft + filters.clientWidth >= filters.scrollWidth - 1) {
                direction = -1;
            } else if (direction === -1 && filters.scrollLeft <= 0) {
                direction = 1;
            }
            filters.scrollLeft += direction * scrollSpeed;
        }
        animationId = requestAnimationFrame(scroll);
    }

    // Stop previous loop if re-initializing
    if (window.menuScrollId) cancelAnimationFrame(window.menuScrollId);
    window.menuScrollId = requestAnimationFrame(scroll);
}

// Filter Products
window.filterProducts = (category) => {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active',
            btn.textContent.toLowerCase().trim() === category ||
            (category === 'all' && btn.textContent.toLowerCase().trim() === 'todos')
        );
    });
    renderProducts(category);
};

// Helper to Format Price
const formatPrice = (price) => {
    if (price == 0 || price === '0') return '<span class="sold-out">AGOTADO</span>';
    return `₡${price}`;
};

// Render Products (Grid)
function renderProducts(category) {
    const filtered = category === 'all'
        ? products
        : products.filter(p => p.category === category);

    productGrid.innerHTML = filtered.map(product => {
        let mediaHtml = '';

        // Helper to extract dimensions and create optimized img tag
        const createOptimizedImg = (url, alt) => {
            const sizeMatch = url.match(/opt(\d+)x(\d+)/);
            const widthAttr = sizeMatch ? `width="${sizeMatch[1]}"` : '';
            const heightAttr = sizeMatch ? `height="${sizeMatch[2]}"` : '';
            return `<img src="${url}" alt="${alt}" loading="lazy" decoding="async" ${widthAttr} ${heightAttr}>`;
        };

        // Show first media item in card
        if (product.media && product.media.length > 0) {
            const first = product.media[0];
            if (first.type === 'image') {
                mediaHtml = createOptimizedImg(first.url, product.title);
            } else if (first.type === 'video') {
                const videoId = first.url.split('v=')[1]?.split('&')[0];
                mediaHtml = `<div style="width:100%;height:100%;background:#000;display:flex;align-items:center;justify-content:center;color:white;font-size:3rem">▶</div>`;
                if (videoId) {
                    mediaHtml = `<img src="https://img.youtube.com/vi/${videoId}/mqdefault.jpg" alt="${product.title}" loading="lazy" decoding="async">`;
                }
            }
        }
        // Fallback for old data with videoUrl/imageUrl
        else if (product.videoUrl) {
            const videoId = product.videoUrl.split('v=')[1]?.split('&')[0];
            mediaHtml = `<img src="https://img.youtube.com/vi/${videoId}/mqdefault.jpg" alt="${product.title}" loading="lazy" decoding="async">`;
        } else if (product.imageUrl) {
            mediaHtml = createOptimizedImg(product.imageUrl, product.title);
        } else {
            mediaHtml = `<div style="width:100%;height:100%;background:linear-gradient(45deg, #333, #444);display:flex;align-items:center;justify-content:center;color:#666">No Image</div>`;
        }

        // Check for video availability
        let hasVideo = false;
        if (product.media && product.media.some(m => m.type === 'video')) {
            hasVideo = true;
        } else if (product.videoUrl) {
            hasVideo = true;
        }

        const videoBtnHtml = hasVideo
            ? `<button class="video-btn" onclick="event.stopPropagation(); openProductModal('${product.id}', true)">
                 Ver Video ▶
               </button>`
            : '';

        const overlayHtml = hasVideo ? `
            <div class="play-overlay">
                <i class="fas fa-play"></i>
            </div>
        ` : '';

        const isSoldOut = product.price == 0 || product.price === '0';
        const priceDisplay = formatPrice(product.price);
        const btnState = isSoldOut ? 'disabled style="background:#6b7280; opacity:0.7; cursor:not-allowed"' : '';
        const btnText = isSoldOut ? 'Agotado' : 'Agregar al Carrito';

        return `
            <div class="product-card" onclick="openProductModal('${product.id}', ${hasVideo ? 'true' : 'false'})">
                <div class="product-media">
                    ${overlayHtml}
                    ${mediaHtml}
                </div>
                <div class="product-info">
                    <div class="product-header">
                        <h3 class="product-title">${product.title}</h3>
                        ${videoBtnHtml}
                    </div>
                    <div class="product-price">${priceDisplay}</div>
                    <p class="product-desc">${product.description}</p>
                    
                    <button class="add-btn" onclick="event.stopPropagation(); addToCart('${product.id}', null, 1)" ${btnState}>
                        ${btnText}
                    </button>
                </div>
            </div>
        `;
    }).join('');
}


// --- PRODUCT MODAL LOGIC ---

window.openProductModal = (productId, preferVideo = false) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    currentProduct = product;
    currentMediaIndex = 0;

    // Direct to video if requested
    if (preferVideo && product.media) {
        const videoIndex = product.media.findIndex(m => m.type === 'video');
        if (videoIndex !== -1) {
            currentMediaIndex = videoIndex;
        }
    }

    isZoomed = false;
    carouselContainer.classList.remove('zoomed');

    // Reset Quantity
    qtyInput.value = 1;

    // Populate Info
    modalTitle.textContent = product.title;
    modalPrice.innerHTML = formatPrice(product.price);
    modalDesc.textContent = product.description;

    // Check Sold Out
    const isSoldOut = product.price == 0 || product.price === '0';

    // Sizes
    if (product.sizes && product.sizes.length > 0) {
        modalSizesContainer.innerHTML = `
            <select id="modal-size-select" class="size-select" style="margin-bottom:0">
                ${product.sizes.map(s => `<option value="${s}">${s}</option>`).join('')}
            </select>
            `;
    } else {
        modalSizesContainer.innerHTML = '';
    }

    // Add Button
    if (isSoldOut) {
        modalAddBtn.disabled = true;
        modalAddBtn.textContent = 'Agotado';
        modalAddBtn.style.background = '#6b7280';
        modalAddBtn.style.cursor = 'not-allowed';
        modalAddBtn.style.opacity = '0.7';
        modalAddBtn.onclick = null;
    } else {
        modalAddBtn.disabled = false;
        modalAddBtn.textContent = 'Agregar al Carrito';
        modalAddBtn.style.background = ''; // Reset to default CSS
        modalAddBtn.style.cursor = 'pointer';
        modalAddBtn.style.opacity = '1';

        modalAddBtn.onclick = () => {
            let size = null;
            const select = document.getElementById('modal-size-select');
            if (select) size = select.value;

            const qty = parseInt(qtyInput.value) || 1;
            addToCart(product.id, size, qty);
            productModal.classList.remove('visible');
        };
    }

    renderCarousel();
    productModal.classList.add('visible');
};

// Quantity Handlers
qtyMinus.onclick = () => {
    let val = parseInt(qtyInput.value) || 1;
    if (val > 1) qtyInput.value = val - 1;
};

qtyPlus.onclick = () => {
    let val = parseInt(qtyInput.value) || 1;
    qtyInput.value = val + 1;
};


function renderCarousel() {
    // Normalize Media List
    let mediaList = [];
    if (currentProduct.media && currentProduct.media.length > 0) {
        mediaList = currentProduct.media;
    } else {
        // Fallbacks
        if (currentProduct.videoUrl) mediaList.push({ type: 'video', url: currentProduct.videoUrl });
        if (currentProduct.imageUrl) mediaList.push({ type: 'image', url: currentProduct.imageUrl });
    }

    if (mediaList.length === 0) {
        carouselContainer.innerHTML = '<div style="color:white">No Media</div>';
        return;
    }

    // Render Items
    carouselContainer.innerHTML = mediaList.map((m, idx) => {
        const activeClass = idx === currentMediaIndex ? 'active' : '';
        if (m.type === 'video') {
            const videoId = m.url.split('v=')[1]?.split('&')[0];
            return `<iframe class="modal-media-item ${activeClass}" src="https://www.youtube.com/embed/${videoId}" allowfullscreen></iframe>`;
        } else {
            return `<img class="modal-media-item ${activeClass}" src="${m.url}" />`;
        }
    }).join('');

    // Update Dots
    if (mediaList.length > 1) {
        modalDots.innerHTML = mediaList.map((_, idx) => `
            <div class="dot ${idx === currentMediaIndex ? 'active' : ''}" onclick="goToSlide(${idx})"></div>
                `).join('');
        prevBtn.style.display = 'block';
        nextBtn.style.display = 'block';
    } else {
        modalDots.innerHTML = '';
        prevBtn.style.display = 'none';
        nextBtn.style.display = 'none';
    }

    // Setup Zoom (Only for active image)
    const activeImg = carouselContainer.querySelector(`img.active`);
    if (activeImg) {
        setupZoom(activeImg);
    }
}

function setupZoom(img) {
    carouselContainer.onclick = (e) => {
        // Prevent zoom on iframe
        if (e.target.tagName !== 'IMG' && !isZoomed) return;

        isZoomed = !isZoomed;
        if (isZoomed) {
            carouselContainer.classList.add('zoomed');

            // Simple interaction: follow mouse
            carouselContainer.onmousemove = (event) => {
                const rect = carouselContainer.getBoundingClientRect();
                const x = (event.clientX - rect.left) / rect.width * 100;
                const y = (event.clientY - rect.top) / rect.height * 100;
                img.style.transformOrigin = `${x}% ${y}%`;
            };
        } else {
            carouselContainer.classList.remove('zoomed');
            carouselContainer.onmousemove = null;
            img.style.transformOrigin = 'center center';
        }
    };
}

window.goToSlide = (idx) => {
    isZoomed = false;
    carouselContainer.classList.remove('zoomed');
    currentMediaIndex = idx;
    renderCarousel();
};

prevBtn.onclick = () => {
    let listLen = (currentProduct.media && currentProduct.media.length) || 1;
    if (!currentProduct.media || currentProduct.media.length === 0) {
        if (currentProduct.videoUrl || currentProduct.imageUrl) listLen = 1;
    }

    currentMediaIndex = (currentMediaIndex - 1 + listLen) % listLen;
    renderCarousel();
};

nextBtn.onclick = () => {
    let listLen = (currentProduct.media && currentProduct.media.length) || 1;
    currentMediaIndex = (currentMediaIndex + 1) % listLen;
    renderCarousel();
};

closeModalBtn.onclick = () => {
    productModal.classList.remove('visible');
    carouselContainer.innerHTML = '';
};

// --- CART LOGIC ---

window.addToCart = (productId, selectedSize = null, quantity = 1) => {
    const product = products.find(p => p.id === productId);

    if (!selectedSize && product.sizes && product.sizes.length > 0) {
        selectedSize = product.sizes[0];
    }

    // Check if item exists
    const existingItem = cart.find(item => item.id === productId && item.selectedSize === selectedSize);

    if (existingItem) {
        existingItem.quantity = (existingItem.quantity || 1) + quantity;
    } else {
        const cartItem = {
            ...product,
            cartId: Date.now(),
            selectedSize: selectedSize,
            quantity: quantity
        };
        cart.push(cartItem);
    }

    saveCart();
    updateCartUI();

    // Feedback
    if (productModal.classList.contains('visible')) {
        const originalText = modalAddBtn.textContent;
        modalAddBtn.textContent = '¡Agregado!';
        modalAddBtn.style.background = '#22c55e';
        setTimeout(() => {
            // Restore button state based on current product (or just close modal usually)
            if (product.id === currentProduct.id) {
                const isSoldOut = product.price == 0 || product.price === '0';
                if (!isSoldOut) {
                    modalAddBtn.textContent = originalText;
                    modalAddBtn.style.background = '';
                }
            }
        }, 1000);
    }
};

window.removeFromCart = (cartId) => {
    cart = cart.filter(item => item.cartId !== cartId);
    saveCart();
    updateCartUI();
};

window.updateCartQty = (cartId, change) => {
    const item = cart.find(i => i.cartId === cartId);
    if (!item) return;

    const newQty = (item.quantity || 1) + change;
    if (newQty > 0) {
        item.quantity = newQty;
    } else {
        item.quantity = 1;
    }
    saveCart();
    updateCartUI();
};


function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartUI() {
    const totalCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    cartCountEl.textContent = totalCount;

    // Calculate total
    const total = cart.reduce((sum, item) => sum + (parseFloat(item.price) * (item.quantity || 1)), 0);
    cartTotalEl.textContent = `₡${total.toFixed(2)}`;

    // Render Items
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart-msg">Tu carrito está vacío</p>';
    } else {
        cartItemsContainer.innerHTML = cart.map(item => `
            <div class="cart-item">
                <div class="item-details">
                    <span class="item-title">${item.title}</span>
                    <div class="item-meta">
                        ₡${item.price} x ${item.quantity || 1}
                        ${item.selectedSize ? `| Talla: ${item.selectedSize}` : ''}
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 0.5rem; margin-right: 0.5rem;">
                    <button onclick="updateCartQty(${item.cartId}, -1)" style="background:rgba(255,255,255,0.1); border:none; color:white; width:20px; border-radius:4px; cursor:pointer">-</button>
                    <span>${item.quantity || 1}</span>
                    <button onclick="updateCartQty(${item.cartId}, 1)" style="background:rgba(255,255,255,0.1); border:none; color:white; width:20px; border-radius:4px; cursor:pointer">+</button>
                </div>
                <button class="remove-btn" onclick="removeFromCart(${item.cartId})">
                    &times;
                </button>
            </div>
            `).join('');
    }
}

// Modal Handlers (Cart)
const openBtn = document.getElementById('cart-toggle');
const closeBtn = document.getElementById('close-cart');

// Cart Modal Events
openBtn.addEventListener('click', () => cartModal.classList.add('visible'));
closeBtn.addEventListener('click', () => cartModal.classList.remove('visible'));

// New Back Buttons
document.getElementById('modal-back-btn').addEventListener('click', () => productModal.classList.remove('visible'));
document.getElementById('cart-back-btn').addEventListener('click', () => cartModal.classList.remove('visible'));
cartModal.addEventListener('click', (e) => {
    if (e.target === cartModal) cartModal.classList.remove('visible');
});

// Checkout (WhatsApp)
const checkoutBtn = document.getElementById('checkout-btn');
checkoutBtn.addEventListener('click', () => {
    if (cart.length === 0) return;

    let message = `Hola, quiero realizar el siguiente pedido en ${storeName}: \n\n`;
    let total = 0;

    cart.forEach(item => {
        const qty = item.quantity || 1;
        message += `• (${qty}x) ${item.title} `;
        if (item.selectedSize) message += ` [${item.selectedSize}]`;
        message += ` - ₡${(parseFloat(item.price) * qty).toFixed(2)} \n`;
        total += parseFloat(item.price) * qty;
    });

    message += `\nTotal: ₡${total.toFixed(2)}`;

    const cleanNumber = whatsappNumber.replace(/\D/g, '');
    const url = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
});

// Start App
init();

// Global Close Functions
window.closeProductModal = () => {
    productModal.classList.remove('visible');
};

window.closeCartModal = () => {
    cartModal.classList.remove('visible');
};
